#include "welcome.h"
#include "ui_welcome.h"
#include <QDebug>
#include "client.h"

Welcome::Welcome(Client* client, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Welcome)
{
    ui->setupUi(this);
    m_client = client;  //记录当前客户端
    connect(ui->loginAndRegisterBtn, &QPushButton::clicked, this, &Welcome::getServer);
}

Welcome::~Welcome()
{
    delete ui;
}


//登陆操作
void Welcome::login()
{
     qDebug() << "登陆操作";
     baseService::LoginRequest loginRequeset;
     loginRequeset.set_uid(ui->uid->text().toInt());
     loginRequeset.set_passwd(ui->passwd->text().toStdString());
     m_client->tcpSendMsg((int)baseService::ID_LoginRequest, m_client->baseClient, &loginRequeset);
}

//选择注册操作
void Welcome::chooseRegister()
{
    qDebug() << "切换为注册操作";
    ui->loginAndRegisterBtn->setText("注册");
    ui->uidLabel->setText("昵称：");
    m_client->isNewUser = true;
}

//注册操作
void Welcome::registerUser()
{
    qDebug() << "注册操作";
    baseService::RegisterRequest registerData;
    registerData.set_name(ui->uid->text().toStdString());
    registerData.set_modid(1);  //注册用户
    registerData.set_passwd(ui->passwd->text().toStdString());
    registerData.set_summary("可爱的夏天");
    m_client->tcpSendMsg((int)baseService::ID_RegisterRequest, m_client->baseClient, &registerData);
}

//获取server操作
void Welcome::getServer(){
      qDebug() << "获取基础服务器操作";
    lbService::GetServerRequest responseData;
    responseData.set_modid(1);  //1代表请求基础ip，2代表请求流媒体ip
    responseData.set_id(ui->uid->text().toInt());  //客户uid
    m_client->udpSendMsg((int)lbService::ID_GetServerRequest,
     &m_client->mediaClient->m_recvAddr, &responseData);
}

