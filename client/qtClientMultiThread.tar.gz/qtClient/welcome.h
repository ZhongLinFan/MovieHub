#ifndef WELCOME_H
#define WELCOME_H

#include <QMainWindow>

class Client;
namespace Ui {
class Welcome;
}

class Welcome : public QMainWindow
{
    Q_OBJECT

public:
    explicit Welcome(Client* client, QWidget *parent = nullptr);
    ~Welcome();
    //登陆操作
    void login();
    //选择注册操作
    void chooseRegister();
    //注册操作
    void registerUser();
    //获取server操作
    void getServer();
private:
    Ui::Welcome *ui;
    Client* m_client;  //当前的页面所属的client
};

#endif // WELCOME_H
