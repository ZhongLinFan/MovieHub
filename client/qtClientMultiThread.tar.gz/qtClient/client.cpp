#include "client.h"
#include "welcome.h"
#include "mainwindow.h"
#include <functional>
#include <thread>

Client::Client(QObject *parent): QObject(parent)
{
    welcome = new Welcome(this);
    mainWindow = new MainWindow(this);
    mediaClient = new UdpClient("127.0.0.1", 10001);  //lb服务器的地址
    baseClient = new TcpClient();
    connected = false;

    //注册收到lb服务器返回的基础服务器ip之后的操作
    auto obtainedBaseIpFunc = std::bind(&Client::handleObtainedBaseIp, this,
        std::placeholders::_1, std::placeholders::_2);
    mediaClient->addMsgRouter((int)lbService::ID_GetServerResponse, obtainedBaseIpFunc);
    //注册登陆之后的处理函数，如果登陆成功，应该切换到主窗口，登陆失败就不用管
    auto loginResultFunc = std::bind(&Client::handleLoginResult, this,
        std::placeholders::_1, std::placeholders::_2);
    baseClient->addMsgRouter((int)baseService::ID_LoginResponse, loginResultFunc);
    //注册注册之后的处理函数，注册成功，应该切换到主窗口，注册失败不用管
    //登陆成功之前没有返回result，而是直接请求各种列表

    //注册相关的函数，如果客户端输入登陆按钮，media立马发给udp一个server请求，
    //如果返回一个server，那么把刚才输入的信息发给tcp，如果登陆成功，应该切换到mainWindow，
    //如果登陆失败，应该保持现状
}

void Client::run()
{
    //在一个线程启动udp
    std::thread baseClientRunner(&TcpClient::run, baseClient);
    //在一个线程启动tcp
    std::thread mediaClientRunner(&UdpClient::run, mediaClient);
    welcome->show();
}

void Client::handleObtainedBaseIp(Udp* conn, void* userData){
    auto obtainedIpData = parseRequest<Udp, lbService::GetServerResponse>(conn);
    //修改baseClient的ip
    baseClient->changeServer(obtainedIpData->host(0).ip().data(), obtainedIpData->host(0).port());
    //连接成功之后发送登陆或者注册请求
    if(baseClient->connectServer()){
        connected = true;
        //为什么要把登陆和注册操作放在welcome里，因为可以很方便的获取那个页面的值，这里调用一下接口就行
        if(isNewUser){  //如果是新用户就注册
            welcome->registerUser();

        }else{  //登陆操作
            welcome->login();
        }
    }
}

void Client::handleLoginResult(NetConnection*conn, void* userData){
   auto loginResultData = parseRequest<NetConnection, baseService::LoginResponse>(conn);
    std::cout << "当前用户：" << loginResultData->uid() << std::endl;
    if (loginResultData->has_result()) {
        //在这里需要切换为主窗口，或者释放登陆界面
        std::cout << "登录结果：" << loginResultData->result() << std::endl;
    }
    else if (loginResultData->has_favoritelist()) {
        //这个应该是那个窗口该干的事情，不应该在这里更新
        std::cout << "喜欢电影列表：" << std::endl;
        for (int i = 0; i < loginResultData->favoritelist().file_size(); i++) {
            std::cout << "fid：" << loginResultData->favoritelist().file(i).fid() << "\tname：" << loginResultData->favoritelist().file(i).name() << std::endl;
        }
    }
    else if (loginResultData->has_friendlist()) {
        std::cout << "朋友列表：" << std::endl;
        for (int i = 0; i < loginResultData->friendlist().friend__size(); i++) { //注意friend是关键字，所以protobuf会在后面加_
            std::cout << "uid：" << loginResultData->friendlist().friend_(i).uid() << "\tname：" << loginResultData->friendlist().friend_(i).name() << std::endl;
        }
    }
    else if (loginResultData->has_grouplist()) {
        std::cout << "群组列表：" << std::endl;
        for (int i = 0; i < loginResultData->grouplist().group_size(); i++) {
            std::cout << "gid：" << loginResultData->grouplist().group(i).gid() << "\tname：" << loginResultData->grouplist().group(i).name() << std::endl;
        }
    }
    else {
        std::cout << "未知列表" << std::endl;
    }
}

void Client::handleRegisterResult(NetConnection*conn, void* userData){
    auto registerResultData = parseRequest<NetConnection, baseService::RegisterResponse>(conn);
    if(registerResultData->modid() == 1){  //注册用户结果
        if(registerResultData->result() == 1){  //注册成功
            //在这里切换页面

        }else{
            //注册失败，什么都不用管
        }
    }else if(registerResultData->modid() == 2){  //注册群组


    }else{  //未知注册id


    }
}


