#ifndef CLIENT_H
#define CLIENT_H

#include "baseService.pb.h"
#include "lbService.pb.h"
#include "Udp.h"
#include "TcpClient.h"

#include <QObject>

//两个类互相包含，需要前置声明
class Welcome;
class MainWindow;

//要使用qt中的多线程，所以需要这个类继承QObject
class Client: public QObject
{
    Q_OBJECT
public:
    Client(QObject *parent = nullptr);
    void run();
    //获取ip之后的操作
    void handleObtainedBaseIp(Udp*conn, void* userData);
    //登陆之后，会有4个返回结果都要处理
    void handleLoginResult(NetConnection*conn, void* userData);
    //注册结果处理
    void handleRegisterResult(NetConnection*conn, void* userData);
    //下面的公共函数都是其他模块直接复制过来的，所以没有解释
    //至于为啥要在头文件定义，看主要bug记录
public:
    // 公共解析函数
    template<class Conn_T, class Request_T>
    std::shared_ptr<Request_T> parseRequest(Conn_T* conn){
        Debug("开始解析数据");
        std::shared_ptr<Request_T> requestData (new Request_T);
        requestData->ParseFromArray(conn->m_request->m_data, conn->m_request->m_msglen);
        return std::move(requestData);  //防止多次深拷贝
    }
    //公共打包函数
    template<class Conn_T, class Response_T>
    bool packageMsg(int responseID, Conn_T* conn, Response_T* responseData){
        Debug("requestHandle开始回复数据");
        //responseData的结果序列化
        std::string responseSerial;
        responseData->SerializeToString(&responseSerial);
        //封装response
        auto response = conn->m_response;
        response->m_msgid = responseID;
        response->m_data = &responseSerial[0];
        response->m_msglen = responseSerial.size();
        response->m_state = HandleState::Done;
        return true;
    }
    //udp发送函数
    template<class Response_T>
    void udpSendMsg(int responseID, sockaddr_in* to, Response_T* responseData){
        if (packageMsg<Udp, Response_T>(responseID, mediaClient, responseData)) {
            mediaClient->sendMsg(*to);
        }
        else {
            std::cout << "msgId为-1，已拒绝发送该包" << std::endl;
        }

    }
    //tcp发送函数
    template<class Response_T>
    void tcpSendMsg(int responseID, NetConnection* conn, Response_T* responseData){
        if (packageMsg<NetConnection, Response_T>( responseID, conn, responseData)) {
            //Debug("tcpSendMsg已经打包数据完成，准备执行发送函数");
            conn->sendMsg();
        }
        else {
            std::cout << "msgId为-1，已拒绝发送该包" << std::endl;
        }

    }
public:
    Welcome* welcome;
    MainWindow* mainWindow;
    Udp* mediaClient;
    TcpClient* baseClient;
    bool connected;   //是否连接到服务器
    bool isNewUser;   //是否为新用户
};

#endif // CLIENT_H
